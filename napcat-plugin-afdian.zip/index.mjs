import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const PLUGIN_NAME = 'AfdianNap';
const DEVELOPER_TEXT = '开发者：FengLan ｜ 爱发电：https://www.ifdian.net/a/FengLan1201';
const startTime = Date.now();
const MAX_DEDUPE_SIZE = 5000;
const AFDIAN_API_TIMEOUT_MS = 15000;
const processedIds = new Set();
let logger = null;
let pluginCtx = null;
let notificationHistory = [];
let runtimeStatePath = '';
const plugin_config_ui = [];

const defaultConfig = {
  enabled: true,
  webhookPath: '/afdian/webhook',
  afdianUserId: '',
  afdianToken: '',
  afdianApiBaseUrl: 'https://afdian.com/api/open',
  afdianHomeUrl: '',
  sponsorListPages: 5,
  commandEnabled: true,
  commandPrefix: '/afdian',
  commandAdmins: [],
  joinVerifyEnabled: false,
  joinVerifyGroups: [],
  joinVerifyPages: 5,
  joinVerifyMinAmount: 0,
  joinVerifyAdminGroups: [],
  joinVerifyAdminUsers: [],
  verifySignature: true,
  notifyGroups: [],
  notifyUsers: [],
  messageTemplate: '收到新的爱发电支持\n用户：{{userName}}\n方案：{{planTitle}}\n金额：{{amount}} 元\n订单：{{outTradeNo}}\n时间：{{time}}',
  dedupeEnabled: true,
  historyLimit: 100,
  debugLog: false
};

let currentConfig = { ...defaultConfig };

const plugin_init = async (ctx) => {
  pluginCtx = ctx;
  logger = ctx.logger;
  logger.info('AfdianNap 已初始化');

  loadConfig(ctx.configPath);
  runtimeStatePath = buildRuntimeStatePath(ctx.configPath);
  loadRuntimeState(runtimeStatePath);
  currentConfig = normalizeConfig(currentConfig);
  buildConfigUI(ctx);

  const webhookPath = normalizeWebhookPath(currentConfig.webhookPath);
  registerWebhookRoute(ctx, webhookPath);

  ctx.router.get('/status', (_req, res) => {
    res.json({
      code: 0,
      data: {
        pluginName: ctx.pluginName || PLUGIN_NAME,
        enabled: currentConfig.enabled,
        uptime: Date.now() - startTime,
        uptimeFormatted: formatUptime(Date.now() - startTime),
        webhookPath,
        webhookUrlHint: buildWebhookUrlHint(_req, ctx, webhookPath),
        targetCount: currentConfig.notifyGroups.length + currentConfig.notifyUsers.length,
        groupCount: currentConfig.notifyGroups.length,
        userCount: currentConfig.notifyUsers.length,
        historyCount: notificationHistory.length,
        lastNotification: notificationHistory[0] || null,
        developer: DEVELOPER_TEXT,
        config: getSafeConfig()
      }
    });
  });

  ctx.router.get('/config', (_req, res) => {
    res.json({ code: 0, data: getSafeConfig() });
  });

  ctx.router.get('/static/plugin-info.js', (_req, res) => {
    try {
      res.type('application/javascript');
      res.send(`window.__PLUGIN_NAME__ = ${JSON.stringify(ctx.pluginName || PLUGIN_NAME)};`);
    } catch (_error) {
      res.status(500).send('// plugin-info failed');
    }
  });

  ctx.router.post('/config', (req, res) => {
    try {
      const oldWebhookPath = currentConfig.webhookPath;
      const nextConfig = mergeConfigFromRequest(req.body || {});
      currentConfig = normalizeConfig(nextConfig);
      saveConfig(ctx.configPath, currentConfig);
      const webhookPathChanged = currentConfig.webhookPath !== oldWebhookPath;
      res.json({
        code: 0,
        message: webhookPathChanged
          ? '配置已保存。Webhook 路径已变更，请重启 NapCat 才会重新注册路由。'
          : '配置已保存。',
        data: getSafeConfig()
      });
    } catch (error) {
      logger?.error('保存配置失败:', error);
      res.status(500).json({ code: -1, message: error.message });
    }
  });

  ctx.router.get('/history', (_req, res) => {
    res.json({ code: 0, data: notificationHistory });
  });

  ctx.router.get('/orders', async (req, res) => {
    try {
      const page = Math.max(1, Number(req.query?.page) || 1);
      const perPage = Math.min(100, Math.max(1, Number(req.query?.per_page || req.query?.perPage) || 20));
      const data = await queryAfdianOrders({ page, per_page: perPage });
      res.json({ code: 0, data });
    } catch (error) {
      logger?.error('查询爱发电订单失败:', error);
      res.status(500).json({ code: -1, message: error.message });
    }
  });

  ctx.router.post('/query-order', async (req, res) => {
    try {
      const outTradeNo = String(req.body?.out_trade_no || req.body?.outTradeNo || '').trim();
      if (!outTradeNo) {
        res.status(400).json({ code: -1, message: '缺少订单号 out_trade_no' });
        return;
      }
      const data = await queryAfdianOrder(outTradeNo);
      res.json({ code: 0, data });
    } catch (error) {
      logger?.error('查询爱发电订单详情失败:', error);
      res.status(500).json({ code: -1, message: error.message });
    }
  });

  ctx.router.post('/test-api', async (_req, res) => {
    try {
      const data = await queryAfdianOrders({ page: 1, per_page: 1 });
      res.json({
        code: 0,
        message: '爱发电 API 测试成功',
        data: {
          ok: true,
          sampleCount: extractAfdianOrderList(data).length,
          raw: data
        }
      });
    } catch (error) {
      logger?.error('测试爱发电 API 失败:', error);
      res.status(500).json({ code: -1, message: error.message });
    }
  });

  ctx.router.post('/test-notify', async (req, res) => {
    try {
      const event = normalizeAfdianEvent(req.body?.event || buildTestEvent());
      const result = await notifyAfdianEvent(ctx, event, { isTest: true, skipDedupe: true });
      res.json({ code: 0, message: '测试通知已执行', data: result });
    } catch (error) {
      logger?.error('测试通知失败:', error);
      res.status(500).json({ code: -1, message: error.message });
    }
  });

  ctx.router.post('/clear-history', (_req, res) => {
    notificationHistory = [];
    processedIds.clear();
    saveRuntimeState(runtimeStatePath);
    res.json({ code: 0, message: '历史记录和去重缓存已清空' });
  });

  ctx.router.post('/clear-dedupe', (_req, res) => {
    processedIds.clear();
    saveRuntimeState(runtimeStatePath);
    res.json({ code: 0, message: '去重缓存已清空' });
  });

  ctx.router.getNoAuth('/health', (_req, res) => {
    res.json({
      code: 0,
      data: {
        status: 'ok',
        pluginName: ctx.pluginName || PLUGIN_NAME,
        uptime: Date.now() - startTime,
        uptimeFormatted: formatUptime(Date.now() - startTime)
      }
    });
  });

  ctx.router.static('/static', 'webui');
  ctx.router.staticOnMem('/dynamic', [
    {
      path: '/info.json',
      contentType: 'application/json',
      content: () => JSON.stringify({
        pluginName: ctx.pluginName || PLUGIN_NAME,
        developer: DEVELOPER_TEXT,
        generatedAt: new Date().toISOString(),
        uptime: Date.now() - startTime,
        config: getSafeConfig(),
        historyCount: notificationHistory.length
      }, null, 2)
    }
  ]);

  ctx.router.page({
    path: 'dashboard',
    title: 'AfdianNap',
    icon: '💜',
    htmlFile: 'webui/dashboard.html',
    description: 'NapCat 爱发电对接助手 — 赞助列表、订单查询、实时通知'
  });

  logger.info('AfdianNap 路由已注册:');
  logger.info('  - 管理 API: /api/Plugin/ext/' + (ctx.pluginName || PLUGIN_NAME) + '/');
  logger.info('  - Webhook: /plugin/' + (ctx.pluginName || PLUGIN_NAME) + '/api' + webhookPath);
  logger.info('  - 扩展页面: /plugin/' + (ctx.pluginName || PLUGIN_NAME) + '/page/dashboard');
};

const plugin_get_config = async () => currentConfig;

const plugin_set_config = async (ctx, config) => {
  currentConfig = normalizeConfig(mergeConfigFromRequest(config || {}));
  if (ctx?.configPath) {
    saveConfig(ctx.configPath, currentConfig);
  }
};

const plugin_config_controller = async (_ctx, _ui, initialConfig) => {
  logger?.info('AfdianNap 配置控制器已初始化', maskSensitiveConfig(initialConfig || {}));
  return () => logger?.info('AfdianNap 配置控制器已清理');
};

const plugin_on_config_change = async (_ctx, _ui, key, value) => {
  logger?.info(`配置字段变化: ${key} = ${key === 'afdianToken' ? maskSecret(value) : value}`);
};

function buildConfigUI(ctx) {
  const items = ctx.NapCatConfig.combine(
    ctx.NapCatConfig.html(`<div style="padding: 10px; background: rgba(127, 82, 255, 0.08); border-radius: 8px;"><h3>💜 AfdianNap</h3><p>NapCat 爱发电对接助手。提供赞助列表、订单查询、实时通知，一键管理粉丝赞助。</p><p>${DEVELOPER_TEXT}</p></div>`),
    ctx.NapCatConfig.boolean('enabled', '启用插件', currentConfig.enabled, '关闭后 Webhook 会接收但不会发送 QQ 通知'),
    ctx.NapCatConfig.text('webhookPath', 'Webhook 路径', currentConfig.webhookPath, '默认 /afdian/webhook；修改后通常需要重启 NapCat 才会重新注册'),
    ctx.NapCatConfig.text('afdianUserId', '爱发电 user_id', currentConfig.afdianUserId, '爱发电开放接口/回调校验使用的 user_id'),
    ctx.NapCatConfig.text('afdianToken', '爱发电 token', currentConfig.afdianToken ? maskSecret(currentConfig.afdianToken) : '', '用于 OpenAPI 订单/赞助列表查询；Webhook 签名测试可保持关闭'),
    ctx.NapCatConfig.text('afdianApiBaseUrl', '爱发电 API 地址', currentConfig.afdianApiBaseUrl, '默认 https://afdian.com/api/open，通常无需修改'),
    ctx.NapCatConfig.text('afdianHomeUrl', '爱发电主页', currentConfig.afdianHomeUrl, `用户发送”${currentConfig.commandPrefix || defaultConfig.commandPrefix} 发电”时展示，例如 https://afdian.com/a/你的ID`),
    ctx.NapCatConfig.text('sponsorListPages', '赞助列表查询页数', String(currentConfig.sponsorListPages), `用户发送”${currentConfig.commandPrefix || defaultConfig.commandPrefix} 赞助列表”时最多查询前 N 页订单，建议 1-10`),
    ctx.NapCatConfig.boolean('commandEnabled', '启用 QQ 指令', currentConfig.commandEnabled, '所有指令统一使用指令前缀；普通用户可查发电主页/赞助列表，管理员可查订单/状态'),
    ctx.NapCatConfig.text('commandPrefix', 'QQ 指令前缀', currentConfig.commandPrefix, '默认 /afdian，例如 /afdian help'),
    ctx.NapCatConfig.text('commandAdminsText', '指令管理员 QQ', currentConfig.commandAdmins.join(','), '留空则不允许 QQ 指令；多个 QQ 号用逗号、空格或换行分隔'),
    ctx.NapCatConfig.boolean('joinVerifyEnabled', '启用入群发电校验', currentConfig.joinVerifyEnabled, '有用户申请加入指定群时，从爱发电备注中查找 QQ 号，匹配则自动通过'),
    ctx.NapCatConfig.text('joinVerifyGroupsText', '入群校验群号', currentConfig.joinVerifyGroups.join(','), '只处理这些群的入群申请；多个群号用逗号、空格或换行分隔'),
    ctx.NapCatConfig.text('joinVerifyPages', '入群校验查询页数', String(currentConfig.joinVerifyPages), '最多查询前 N 页爱发电订单备注，建议 1-10'),
    ctx.NapCatConfig.text('joinVerifyMinAmount', '入群最低发电金额', String(currentConfig.joinVerifyMinAmount), '订单金额达到此数值才自动通过；填 0 表示只校验 QQ 号'),
    ctx.NapCatConfig.text('joinVerifyAdminGroupsText', '入群校验通知群', currentConfig.joinVerifyAdminGroups.join(','), '校验失败/需人工处理时通知这些群'),
    ctx.NapCatConfig.text('joinVerifyAdminUsersText', '入群校验通知用户', currentConfig.joinVerifyAdminUsers.join(','), '校验失败/需人工处理时通知这些 QQ；留空则使用指令管理员 QQ'),
    ctx.NapCatConfig.boolean('verifySignature', '校验签名', currentConfig.verifySignature, '建议开启；如果爱发电回调字段与当前实现不匹配，可临时关闭调试'),
    ctx.NapCatConfig.text('notifyGroupsText', '通知群号', currentConfig.notifyGroups.join(','), '多个群号用逗号、空格或换行分隔'),
    ctx.NapCatConfig.text('notifyUsersText', '通知用户', currentConfig.notifyUsers.join(','), '多个 QQ 号用逗号、空格或换行分隔'),
    ctx.NapCatConfig.text('messageTemplate', '消息模板', currentConfig.messageTemplate, '支持 {{userName}}、{{planTitle}}、{{amount}}、{{outTradeNo}}、{{time}} 等变量'),
    ctx.NapCatConfig.boolean('dedupeEnabled', '重复订单去重', currentConfig.dedupeEnabled, '开启后相同订单号/事件 ID 只推送一次'),
    ctx.NapCatConfig.text('historyLimit', '历史记录上限', String(currentConfig.historyLimit), '保留最近 N 条通知记录'),
    ctx.NapCatConfig.boolean('debugLog', '调试日志', currentConfig.debugLog, '开启后记录更多回调处理日志，不会输出 token 明文')
  );
  plugin_config_ui.splice(0, plugin_config_ui.length, ...(Array.isArray(items) ? items : [items]));
}

function registerWebhookRoute(ctx, webhookPath) {
  const handler = async (req, res) => {
    try {
      if (!currentConfig.enabled) {
        addHistory({
          type: 'webhook',
          status: 'disabled',
          duplicate: false,
          event: normalizeAfdianEvent(req.body || {}),
          targets: [],
          errors: [],
          createdAt: new Date().toISOString()
        });
        res.json({ ec: 200, em: 'ok', code: 0, message: '插件未启用，已忽略回调' });
        return;
      }

      const payload = req.body || {};
      debugLog('收到爱发电 Webhook', sanitizePayload(payload));

      const verifyResult = verifyAfdianSignature(payload, currentConfig, req.headers || {});
      if (!verifyResult.ok) {
        addHistory({
          type: 'webhook',
          status: 'rejected',
          duplicate: false,
          event: normalizeAfdianEvent(payload),
          targets: [],
          errors: [verifyResult.message],
          createdAt: new Date().toISOString()
        });
        res.status(200).json({ ec: 400, em: verifyResult.message, code: -1, message: verifyResult.message });
        return;
      }

      const event = normalizeAfdianEvent(payload);
      const result = await notifyAfdianEvent(ctx, event, { isTest: false });
      res.json({
        ec: 200,
        em: 'ok',
        code: 0,
        message: result.duplicate ? '重复事件，已忽略' : '通知已处理',
        data: {
          duplicate: result.duplicate,
          status: result.status,
          targetCount: result.targets.length,
          successCount: result.targets.filter((item) => item.status === 'success').length
        }
      });
    } catch (error) {
      logger?.error('处理爱发电 Webhook 失败:', error);
      addHistory({
        type: 'webhook',
        status: 'failed',
        duplicate: false,
        event: normalizeAfdianEvent(req.body || {}),
        targets: [],
        errors: [error.message],
        createdAt: new Date().toISOString()
      });
      res.status(200).json({ ec: 500, em: error.message, code: -1, message: error.message });
    }
  };

  if (typeof ctx.router.postNoAuth === 'function') {
    ctx.router.postNoAuth(webhookPath, handler);
  } else if (typeof ctx.router.post === 'function') {
    logger?.warn('当前 NapCat router 未发现 postNoAuth，Webhook 将注册为鉴权 POST 路由；如爱发电无法访问，请升级/确认 NapCat 插件路由 API。');
    ctx.router.post(webhookPath, handler);
  } else {
    throw new Error('当前 NapCat router 不支持 POST 路由，无法注册 Webhook');
  }
}

async function notifyAfdianEvent(ctx, event, options = {}) {
  const dedupeKey = getDedupeKey(event);
  if (!options.skipDedupe && currentConfig.dedupeEnabled && processedIds.has(dedupeKey)) {
    const record = {
      type: options.isTest ? 'test' : 'webhook',
      status: 'duplicate',
      duplicate: true,
      dedupeKey,
      event,
      targets: [],
      errors: [],
      createdAt: new Date().toISOString()
    };
    addHistory(record);
    return record;
  }

  const message = renderTemplate(currentConfig.messageTemplate, event);
  if (!currentConfig.notifyGroups.length && !currentConfig.notifyUsers.length) {
    logger?.warn('收到爱发电事件，但未配置任何通知群或通知用户');
  }
  const targets = [];
  const errors = [];

  for (const groupId of currentConfig.notifyGroups) {
    try {
      await sendGroupMessage(ctx, groupId, message);
      targets.push({ type: 'group', id: groupId, status: 'success' });
    } catch (error) {
      errors.push(`群 ${groupId}: ${error.message}`);
      targets.push({ type: 'group', id: groupId, status: 'failed', error: error.message });
    }
  }

  for (const userId of currentConfig.notifyUsers) {
    try {
      await sendPrivateMessage(ctx, userId, message);
      targets.push({ type: 'private', id: userId, status: 'success' });
    } catch (error) {
      errors.push(`用户 ${userId}: ${error.message}`);
      targets.push({ type: 'private', id: userId, status: 'failed', error: error.message });
    }
  }

  const hasSuccess = targets.some((t) => t.status === 'success');
  const status = targets.length === 0
    ? 'no_targets'
    : errors.length
      ? 'partial_failed'
      : 'success';

  if (!options.skipDedupe && currentConfig.dedupeEnabled && hasSuccess) {
    processedIds.add(dedupeKey);
    if (processedIds.size > MAX_DEDUPE_SIZE) {
      const removeCount = Math.floor(processedIds.size / 2);
      let removed = 0;
      for (const key of processedIds) {
        if (removed >= removeCount) break;
        processedIds.delete(key);
        removed++;
      }
      debugLog(`去重缓存清理：移除 ${removeCount} 条旧记录`);
    }
  }

  const record = {
    type: options.isTest ? 'test' : 'webhook',
    status,
    duplicate: false,
    dedupeKey,
    event,
    targets,
    errors,
    message,
    createdAt: new Date().toISOString()
  };

  addHistory(record);
  return record;
}

async function sendGroupMessage(ctx, groupId, message) {
  await ctx.actions.call('send_msg', {
    message_type: 'group',
    group_id: String(groupId),
    message
  }, ctx.adapterName, ctx.pluginManager.config);
}

async function sendPrivateMessage(ctx, userId, message) {
  await ctx.actions.call('send_msg', {
    message_type: 'private',
    user_id: String(userId),
    message
  }, ctx.adapterName, ctx.pluginManager.config);
}

function verifyAfdianSignature(payload, config, headers = {}) {
  if (!config.verifySignature) {
    return { ok: true, message: '签名校验已关闭' };
  }

  if (!config.afdianToken) {
    return { ok: false, message: '已开启签名校验，但未配置爱发电 token' };
  }

  const signature = String(
    payload.sign ||
    payload.signature ||
    headers['x-afdian-sign'] ||
    headers['x-afdian-signature'] ||
    headers['x-ifdian-sign'] ||
    headers.sign ||
    ''
  ).trim().toLowerCase();

  if (!signature) {
    return { ok: false, message: '回调缺少签名字段 sign/signature' };
  }

  const rawParams = payload.params ?? payload.data ?? payload;
  const params = parseMaybeJson(rawParams);
  const paramsString = typeof rawParams === 'string' ? rawParams : stableStringify(stripSignatureFields(params));
  const ts = payload.ts || payload.timestamp || payload.time || '';
  const userId = payload.user_id || payload.userId || config.afdianUserId || '';
  const bodyWithoutSign = stableStringify(stripSignatureFields(payload));
  const candidates = [
    buildAfdianSign(config.afdianToken, paramsString, ts, userId),
    md5(config.afdianToken + 'params' + paramsString + 'ts' + ts + 'user_id' + userId),
    md5(config.afdianToken + bodyWithoutSign),
    md5(bodyWithoutSign + config.afdianToken),
    md5(config.afdianToken + paramsString),
    md5(paramsString + config.afdianToken)
  ].map((item) => item.toLowerCase());

  if (candidates.includes(signature)) {
    return { ok: true, message: '签名校验通过' };
  }

  return { ok: false, message: '爱发电回调签名校验失败' };
}

async function queryAfdianOrders(params = {}) {
  return callAfdianOpenApi('/query-order', params);
}

async function queryAfdianOrder(outTradeNo) {
  const result = await queryAfdianOrders({ out_trade_no: outTradeNo, page: 1, per_page: 1 });
  const list = extractAfdianOrderList(result);
  return list.find((item) => {
    const event = normalizeAfdianEvent(item);
    return [event.outTradeNo, event.orderId, item && item.trade_no, item && item.id].map(String).includes(String(outTradeNo));
  }) || list[0] || result;
}

async function callAfdianOpenApi(endpoint, params = {}) {
  if (!currentConfig.afdianUserId || !currentConfig.afdianToken) {
    throw new Error('请先配置爱发电 user_id 和 token');
  }
  if (typeof fetch !== 'function') {
    throw new Error('当前 Node.js 环境不支持 fetch，请升级到 Node.js 18+');
  }

  const paramsString = JSON.stringify(params || {});
  const ts = Math.floor(Date.now() / 1000).toString();
  const body = {
    user_id: currentConfig.afdianUserId,
    params: paramsString,
    ts,
    sign: buildAfdianSign(currentConfig.afdianToken, paramsString, ts, currentConfig.afdianUserId)
  };
  const url = `${currentConfig.afdianApiBaseUrl}${endpoint}`;
  debugLog('请求爱发电 OpenAPI', { url, body: { ...body, sign: maskSecret(body.sign) } });

  const response = await fetchWithTimeout(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  }, AFDIAN_API_TIMEOUT_MS);
  const text = await response.text();
  let result;
  try {
    result = text ? JSON.parse(text) : {};
  } catch (_error) {
    throw new Error(`爱发电 API 返回非 JSON：${text.slice(0, 200)}`);
  }
  if (!response.ok) {
    throw new Error(`爱发电 API HTTP ${response.status}: ${result.message || result.error || text}`);
  }
  const ec = result.ec ?? result.code;
  if (ec !== undefined && Number(ec) !== 200 && Number(ec) !== 0) {
    throw new Error(result.em || result.message || `爱发电 API 返回错误 ec=${ec}`);
  }
  return result.data ?? result;
}

function buildAfdianSign(token, paramsString, ts, userId) {
  return md5(`${token}params${paramsString}ts${ts}user_id${userId}`);
}

async function fetchWithTimeout(url, options = {}, timeoutMs = AFDIAN_API_TIMEOUT_MS) {
  if (typeof AbortController !== 'function') {
    return fetch(url, options);
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error(`爱发电 API 请求超时（${Math.round(timeoutMs / 1000)} 秒）`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function extractAfdianOrderList(result) {
  const parsed = parseMaybeJson(result);
  if (Array.isArray(parsed)) return parsed.map(parseMaybeJson);
  const candidates = [
    parsed && parsed.list,
    parsed && parsed.orders,
    parsed && parsed.data && parsed.data.list,
    parsed && parsed.data && parsed.data.orders,
    parsed && parsed.data,
    parsed && parsed.params && parsed.params.list,
    parsed && parsed.params && parsed.params.orders
  ].map(parseMaybeJson);
  const list = candidates.find(Array.isArray) || [];
  return list.map(parseMaybeJson);
}

function parseMaybeJson(value) {
  if (typeof value !== 'string') return value;
  const text = value.trim();
  if (!text || !/^[\[{]/.test(text)) return value;
  try {
    return JSON.parse(text);
  } catch (_error) {
    return value;
  }
}

function normalizeAfdianEvent(payload) {
  const parsedPayload = parseMaybeJson(payload) || {};
  const parsedData = parseMaybeJson(parsedPayload.data);
  const parsedParams = parseMaybeJson(parsedPayload.params);
  const source = parsedData || parsedParams || parseMaybeJson(parsedPayload.order) || parsedPayload;
  const order = parseMaybeJson(source.order) || source;
  const plan = parseMaybeJson(source.plan) || parseMaybeJson(order.plan) || {};
  const user = parseMaybeJson(source.user) || parseMaybeJson(source.sponsor) || parseMaybeJson(source.customer) || {};

  const outTradeNo = pickFirst(
    order.out_trade_no,
    order.outTradeNo,
    order.trade_no,
    order.tradeNo,
    order.order_id,
    order.orderId,
    source.out_trade_no,
    source.order_id,
    parsedPayload.out_trade_no,
    parsedPayload.order_id
  );

  const createdAt = pickFirst(
    order.create_time,
    order.created_at,
    order.pay_time,
    order.time,
    source.create_time,
    source.created_at,
    parsedPayload.create_time,
    parsedPayload.ts,
    parsedPayload.timestamp
  );

  const amount = pickFirst(
    order.total_amount,
    order.amount,
    order.show_amount,
    order.price,
    source.total_amount,
    source.amount,
    parsedPayload.amount
  );

  return {
    eventType: pickFirst(parsedPayload.type, parsedPayload.event, source.type, source.event, 'afdian_order'),
    orderId: pickFirst(order.id, order.order_id, source.id, source.order_id, outTradeNo),
    outTradeNo: outTradeNo || 'unknown',
    userName: pickFirst(user.name, user.user_name, user.nickname, order.user_name, source.user_name, parsedPayload.user_name, '未知用户'),
    userId: pickFirst(user.user_id, user.id, order.user_id, source.user_id, parsedPayload.user_id, ''),
    planTitle: pickFirst(plan.title, plan.name, order.plan_title, order.plan_name, source.plan_title, source.plan_name, '未命名方案'),
    amount: amount === undefined || amount === null || amount === '' ? '未知' : String(amount),
    month: pickFirst(order.month, order.month_count, source.month, ''),
    remark: pickFirst(order.remark, order.message, source.remark, source.message, ''),
    time: formatEventTime(createdAt),
    raw: sanitizePayload(parsedPayload)
  };
}

function renderTemplate(template, event) {
  return String(template || defaultConfig.messageTemplate).replace(/{{\s*([\w.]+)\s*}}/g, (_match, key) => {
    const value = event[key];
    return value === undefined || value === null ? '' : String(value);
  });
}

function getDedupeKey(event) {
  const id = event.outTradeNo && event.outTradeNo !== 'unknown' ? event.outTradeNo : event.orderId;
  if (id) return [event.eventType, id].join(':');
  const rawStr = stableStringify(event.raw || event);
  return [event.eventType, md5(rawStr)].join(':');
}

function addHistory(record) {
  notificationHistory.unshift(record);
  const limit = Math.max(1, Number(currentConfig.historyLimit) || defaultConfig.historyLimit);
  if (notificationHistory.length > limit) {
    notificationHistory = notificationHistory.slice(0, limit);
  }
  saveRuntimeState(runtimeStatePath);
}

function buildRuntimeStatePath(configPath) {
  if (!configPath) return '';
  const parsed = path.parse(configPath);
  return path.join(parsed.dir, `${parsed.name}.state.json`);
}

function loadRuntimeState(statePath) {
  try {
    if (!statePath || !fs.existsSync(statePath)) return;
    const state = JSON.parse(fs.readFileSync(statePath, 'utf-8'));
    if (Array.isArray(state.notificationHistory)) {
      notificationHistory = state.notificationHistory
        .map(sanitizeHistoryRecord)
        .filter(Boolean)
        .slice(0, Math.max(1, Number(currentConfig.historyLimit) || defaultConfig.historyLimit));
    }
    if (Array.isArray(state.processedIds)) {
      processedIds.clear();
      for (const id of state.processedIds.slice(-MAX_DEDUPE_SIZE)) {
        if (id) processedIds.add(String(id));
      }
    }
  } catch (error) {
    logger?.warn('读取爱发电运行状态失败:', error);
  }
}

function saveRuntimeState(statePath) {
  try {
    if (!statePath) return;
    const stateDir = path.dirname(statePath);
    if (!fs.existsSync(stateDir)) {
      fs.mkdirSync(stateDir, { recursive: true });
    }
    const state = {
      notificationHistory: notificationHistory
        .map(sanitizeHistoryRecord)
        .filter(Boolean)
        .slice(0, Math.max(1, Number(currentConfig.historyLimit) || defaultConfig.historyLimit)),
      processedIds: [...processedIds].slice(-MAX_DEDUPE_SIZE),
      updatedAt: new Date().toISOString()
    };
    fs.writeFileSync(statePath, JSON.stringify(state, null, 2), 'utf-8');
  } catch (error) {
    logger?.warn('保存爱发电运行状态失败:', error);
  }
}

function sanitizeHistoryRecord(record) {
  if (!record || typeof record !== 'object') return null;
  const safeRecord = { ...record };
  if (safeRecord.event) safeRecord.event = normalizeAfdianEvent(safeRecord.event);
  if (safeRecord.message) safeRecord.message = String(safeRecord.message).slice(0, 4000);
  return safeRecord;
}

function loadConfig(configPath) {
  try {
    if (configPath && fs.existsSync(configPath)) {
      const savedConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      currentConfig = { ...defaultConfig, ...savedConfig };
    }
  } catch (error) {
    logger?.warn('读取爱发电通知配置失败:', error);
  }
}

function saveConfig(configPath, config) {
  if (!configPath) return;
  const configDir = path.dirname(configPath);
  if (!fs.existsSync(configDir)) {
    fs.mkdirSync(configDir, { recursive: true });
  }
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8');
  notificationHistory = notificationHistory.slice(0, Math.max(1, Number(config.historyLimit) || defaultConfig.historyLimit));
  saveRuntimeState(runtimeStatePath || buildRuntimeStatePath(configPath));
}

function mergeConfigFromRequest(input) {
  const next = { ...currentConfig, ...input };
  if (input.afdianToken && String(input.afdianToken).includes('****')) {
    next.afdianToken = currentConfig.afdianToken;
  }
  if ('notifyGroupsText' in input) {
    next.notifyGroups = parseIdList(input.notifyGroupsText);
  }
  if ('notifyUsersText' in input) {
    next.notifyUsers = parseIdList(input.notifyUsersText);
  }
  if ('commandAdminsText' in input) {
    next.commandAdmins = parseIdList(input.commandAdminsText);
  }
  if ('joinVerifyGroupsText' in input) {
    next.joinVerifyGroups = parseIdList(input.joinVerifyGroupsText);
  }
  if ('joinVerifyAdminGroupsText' in input) {
    next.joinVerifyAdminGroups = parseIdList(input.joinVerifyAdminGroupsText);
  }
  if ('joinVerifyAdminUsersText' in input) {
    next.joinVerifyAdminUsers = parseIdList(input.joinVerifyAdminUsersText);
  }
  return next;
}

function normalizeIdList(value) {
  return parseIdList(value).filter((item) => /^\d+$/.test(item));
}

function normalizeConfig(config) {
  const next = { ...defaultConfig, ...config };
  next.webhookPath = normalizeWebhookPath(next.webhookPath);
  next.afdianUserId = String(next.afdianUserId || '').trim();
  next.afdianToken = String(next.afdianToken || '').trim();
  next.afdianApiBaseUrl = String(next.afdianApiBaseUrl || defaultConfig.afdianApiBaseUrl).trim().replace(/\/+$/, '');
  next.afdianHomeUrl = String(next.afdianHomeUrl || '').trim();
  next.sponsorListPages = Math.min(20, Math.max(1, Number(next.sponsorListPages) || defaultConfig.sponsorListPages));
  next.commandPrefix = String(next.commandPrefix || defaultConfig.commandPrefix).trim() || defaultConfig.commandPrefix;
  next.notifyGroups = normalizeIdList(next.notifyGroups);
  next.notifyUsers = normalizeIdList(next.notifyUsers);
  next.commandAdmins = normalizeIdList(next.commandAdmins);
  next.joinVerifyGroups = normalizeIdList(next.joinVerifyGroups);
  next.joinVerifyAdminGroups = normalizeIdList(next.joinVerifyAdminGroups);
  next.joinVerifyAdminUsers = normalizeIdList(next.joinVerifyAdminUsers);
  next.joinVerifyPages = Math.min(20, Math.max(1, Number(next.joinVerifyPages) || defaultConfig.joinVerifyPages));
  next.joinVerifyMinAmount = Math.max(0, Number(next.joinVerifyMinAmount) || 0);
  next.historyLimit = Math.min(1000, Math.max(1, Number(next.historyLimit) || defaultConfig.historyLimit));
  next.enabled = parseBoolean(next.enabled, defaultConfig.enabled);
  next.commandEnabled = parseBoolean(next.commandEnabled, defaultConfig.commandEnabled);
  next.joinVerifyEnabled = parseBoolean(next.joinVerifyEnabled, defaultConfig.joinVerifyEnabled);
  next.verifySignature = parseBoolean(next.verifySignature, defaultConfig.verifySignature);
  next.dedupeEnabled = parseBoolean(next.dedupeEnabled, defaultConfig.dedupeEnabled);
  next.debugLog = parseBoolean(next.debugLog, defaultConfig.debugLog);
  return next;
}

function parseIdList(value) {
  if (Array.isArray(value)) return value.map(String).map((item) => item.trim()).filter(Boolean);
  return String(value || '').split(/[\s,，;；]+/).map((item) => item.trim()).filter(Boolean);
}

function parseBoolean(value, fallback = false) {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value !== 0;
  if (typeof value === 'string') {
    const text = value.trim().toLowerCase();
    if (['true', '1', 'yes', 'on', '启用', '是'].includes(text)) return true;
    if (['false', '0', 'no', 'off', '禁用', '否'].includes(text)) return false;
  }
  return fallback;
}

function normalizeWebhookPath(value) {
  const text = String(value || defaultConfig.webhookPath).trim();
  const normalized = text.startsWith('/') ? text : `/${text}`;
  if (!/^\/[A-Za-z0-9/_-]+$/.test(normalized) || normalized.includes('..')) {
    throw new Error('Webhook 路径只能包含字母、数字、斜杠、下划线和短横线');
  }
  return normalized;
}

function getSafeConfig() {
  return {
    ...currentConfig,
    afdianToken: currentConfig.afdianToken ? maskSecret(currentConfig.afdianToken) : '',
    notifyGroupsText: currentConfig.notifyGroups.join(','),
    notifyUsersText: currentConfig.notifyUsers.join(','),
    commandAdminsText: currentConfig.commandAdmins.join(','),
    joinVerifyGroupsText: currentConfig.joinVerifyGroups.join(','),
    joinVerifyAdminGroupsText: currentConfig.joinVerifyAdminGroups.join(','),
    joinVerifyAdminUsersText: currentConfig.joinVerifyAdminUsers.join(',')
  };
}

function maskSensitiveConfig(config) {
  return { ...config, afdianToken: config.afdianToken ? maskSecret(config.afdianToken) : '' };
}

function maskSecret(value) {
  const text = String(value || '');
  if (!text) return '';
  if (text.length <= 8) return text.slice(0, 2) + '****';
  return text.slice(0, 4) + '****' + text.slice(-4);
}

function sanitizePayload(payload) {
  const parsed = parseMaybeJson(payload);
  if (!parsed || typeof parsed !== 'object') return parsed;
  const cloned = JSON.parse(JSON.stringify(parsed));
  for (const key of Object.keys(cloned)) {
    if (/token|secret|key/i.test(key)) {
      cloned[key] = maskSecret(cloned[key]);
    } else if (cloned[key] && typeof cloned[key] === 'object') {
      cloned[key] = sanitizePayload(cloned[key]);
    }
  }
  return cloned;
}

function stripSignatureFields(value) {
  const parsed = parseMaybeJson(value);
  if (!parsed || typeof parsed !== 'object') return parsed;
  const cloned = JSON.parse(JSON.stringify(parsed));
  delete cloned.sign;
  delete cloned.signature;
  return cloned;
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(stableStringify).join(',') + ']';
  return '{' + Object.keys(value).sort().map((key) => JSON.stringify(key) + ':' + stableStringify(value[key])).join(',') + '}';
}

function md5(value) {
  return crypto.createHash('md5').update(String(value)).digest('hex');
}

function pickFirst(...values) {
  return values.find((value) => value !== undefined && value !== null && value !== '');
}

function formatEventTime(value) {
  if (!value) return new Date().toLocaleString('zh-CN');
  if (typeof value === 'number' || /^\d+$/.test(String(value))) {
    const number = Number(value);
    const ms = number > 1e12 ? number : number * 1000;
    return new Date(ms).toLocaleString('zh-CN');
  }
  const date = new Date(value);
  if (!Number.isNaN(date.getTime())) return date.toLocaleString('zh-CN');
  return String(value);
}

function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days > 0) return `${days}天 ${hours % 24}小时 ${minutes % 60}分钟`;
  if (hours > 0) return `${hours}小时 ${minutes % 60}分钟`;
  if (minutes > 0) return `${minutes}分钟 ${seconds % 60}秒`;
  return `${seconds}秒`;
}

function buildWebhookUrlHint(req, ctx, webhookPath) {
  const pluginName = ctx.pluginName || PLUGIN_NAME;
  const protocol = req?.protocol || 'http';
  const host = req?.headers?.host || '<你的 NapCat 公网域名>';
  return `${protocol}://${host}/plugin/${pluginName}/api${webhookPath}`;
}

function buildTestEvent() {
  return {
    eventType: 'test',
    orderId: 'test-' + Date.now(),
    outTradeNo: 'TEST-' + Date.now(),
    userName: '测试发电用户',
    userId: 'afdian-test-user',
    planTitle: '测试赞助方案',
    amount: '6.66',
    month: '1',
    remark: '这是一条测试通知',
    time: new Date().toLocaleString('zh-CN'),
    raw: { test: true }
  };
}

function debugLog(message, data) {
  if (currentConfig.debugLog) {
    logger?.info(message, data);
  }
}

async function plugin_onevent(ctx, event) {
  if (!currentConfig.joinVerifyEnabled) return;
  if (!isGroupAddRequestEvent(event)) {
    if (currentConfig.debugLog && event?.post_type === 'request') {
      debugLog('收到未处理的请求事件', sanitizePayload(event));
    }
    return;
  }

  const groupId = String(event.group_id || '');
  const userId = String(event.user_id || '');
  if (!groupId || !userId) return;
  if (!currentConfig.joinVerifyGroups.includes(groupId)) return;

  try {
    const matched = await findAfdianOrderByQQ(userId);
    if (matched) {
      const amount = matched.amount;
      const minAmount = Number(currentConfig.joinVerifyMinAmount) || 0;

      if (!Number.isFinite(amount) && minAmount > 0) {
        await notifyJoinVerifyAdmins(ctx, formatJoinVerifyAlert(event, {
          status: 'amount_not_enough',
          message: `爱发电备注 QQ 匹配，但发电金额无效（原始值：${matched.event.amount}），无法校验是否达到入群规则 ${formatAmount(minAmount)} 元，请管理员人工处理。`,
          order: matched.order,
          afdianEvent: matched.event,
          matchedQQs: matched.qqs
        }));
        return;
      }

      const effectiveAmount = Number.isFinite(amount) ? amount : 0;
      if (effectiveAmount < minAmount) {
        await notifyJoinVerifyAdmins(ctx, formatJoinVerifyAlert(event, {
          status: 'amount_not_enough',
          message: `爱发电备注 QQ 匹配，但发电金额 ${formatAmount(effectiveAmount)} 元未达到入群规则 ${formatAmount(minAmount)} 元，请管理员人工处理。`,
          order: matched.order,
          afdianEvent: matched.event,
          matchedQQs: matched.qqs
        }));
        return;
      }

      if (event.flag) {
        await approveGroupRequest(ctx, event);
        await notifyJoinVerifyAdmins(ctx, formatJoinVerifyAlert(event, {
          status: 'approved',
          message: `爱发电备注 QQ 校验通过，发电金额 ${formatAmount(effectiveAmount)} 元已达到入群规则 ${formatAmount(minAmount)} 元，已自动同意入群。`,
          order: matched.order,
          afdianEvent: matched.event,
          matchedQQs: matched.qqs
        }));
      } else {
        await notifyJoinVerifyAdmins(ctx, formatJoinVerifyAlert(event, {
          status: 'matched_no_flag',
          message: `爱发电备注 QQ 校验通过，发电金额 ${formatAmount(effectiveAmount)} 元已达到入群规则 ${formatAmount(minAmount)} 元，但事件缺少 flag，无法自动同意，请管理员手动处理。`,
          order: matched.order,
          afdianEvent: matched.event,
          matchedQQs: matched.qqs
        }));
      }
      return;
    }

    await notifyJoinVerifyAdmins(ctx, formatJoinVerifyAlert(event, {
      status: 'not_found',
      message: '未在爱发电订单备注中找到与申请 QQ 相符的号码，请管理员人工核验。'
    }));
  } catch (error) {
    logger?.error('入群爱发电校验失败:', error);
    await notifyJoinVerifyAdmins(ctx, formatJoinVerifyAlert(event, {
      status: 'failed',
      message: `爱发电查询失败：${error.message}，请管理员人工处理。`
    }));
  }
}

function isGroupAddRequestEvent(event) {
  return event?.post_type === 'request' && event?.request_type === 'group' && (!event.sub_type || ['add', 'invite'].includes(String(event.sub_type)) || String(event.sub_type).includes('add'));
}

async function findAfdianOrderByQQ(qq) {
  const targetQQ = String(qq);
  const perPage = 100;
  const maxPages = currentConfig.joinVerifyPages || defaultConfig.joinVerifyPages;
  let bestMatch = null;

  for (let page = 1; page <= maxPages; page++) {
    const result = await queryAfdianOrders({ page, per_page: perPage });
    const orders = extractAfdianOrderList(result);
    if (!orders.length) break;

    for (const order of orders) {
      const event = normalizeAfdianEvent(order);
      const qqs = extractQQNumbers(event.remark);
      if (!qqs.includes(targetQQ)) continue;

      const amount = parseAmount(event.amount);
    if (!bestMatch || !Number.isFinite(bestMatch.amount) || amount > bestMatch.amount) {
        bestMatch = { order, event, qqs, amount };
      }
    }
  }

  return bestMatch;
}

function extractQQNumbers(text) {
  const result = [];
  const matcher = /(^|\D)(\d{5,12})(?=\D|$)/g;
  let match;
  while ((match = matcher.exec(String(text || ''))) !== null) {
    result.push(match[2]);
  }
  return [...new Set(result)];
}

async function approveGroupRequest(ctx, event) {
  await ctx.actions.call('set_group_add_request', {
    flag: String(event.flag),
    sub_type: event.sub_type || 'add',
    approve: true,
    reason: '爱发电备注 QQ 校验通过'
  }, ctx.adapterName, ctx.pluginManager.config);
}

async function notifyJoinVerifyAdmins(ctx, message) {
  const groups = currentConfig.joinVerifyAdminGroups;
  const users = currentConfig.joinVerifyAdminUsers.length ? currentConfig.joinVerifyAdminUsers : currentConfig.commandAdmins;
  for (const groupId of groups) {
    await sendGroupMessage(ctx, groupId, message).catch((error) => logger?.warn(`通知入群校验群 ${groupId} 失败:`, error));
  }
  for (const userId of users) {
    await sendPrivateMessage(ctx, userId, message).catch((error) => logger?.warn(`通知入群校验用户 ${userId} 失败:`, error));
  }
  if (!groups.length && !users.length) {
    logger?.warn('入群爱发电校验结果没有可通知的管理员目标，请配置入群校验通知群、通知用户或指令管理员 QQ。');
  }
}

function formatJoinVerifyAlert(event, verdict) {
  const safeComment = event.comment ? String(event.comment).slice(0, 300) : '';
  const lines = [
    '💜 爱发电入群校验',
    `状态：${verdict.message}`,
    `群号：${event.group_id || '未知'}`,
    `申请 QQ：${event.user_id || '未知'}`
  ];
  if (safeComment) lines.push(`申请备注：${safeComment}`);
  if (event.flag) lines.push(`请求 flag：${event.flag}`);
  if (verdict.afdianEvent) {
    lines.push(`爱发电用户：${verdict.afdianEvent.userName}`);
    lines.push(`方案：${verdict.afdianEvent.planTitle}`);
    lines.push(`金额：${verdict.afdianEvent.amount} 元`);
    lines.push(`订单：${verdict.afdianEvent.outTradeNo || verdict.afdianEvent.orderId}`);
    lines.push(`发电备注：${verdict.afdianEvent.remark || '无'}`);
  }
  return lines.join('\n');
}

async function plugin_onmessage(ctx, event) {
  if (!currentConfig.commandEnabled || event?.post_type !== 'message') return;
  const raw = event.raw_message || '';
  const text = raw.replace(/\[CQ:[^\]]+\]/g, '').trim();
  const prefix = currentConfig.commandPrefix || defaultConfig.commandPrefix;
  if (!text.startsWith(prefix)) return;

  const args = text.slice(prefix.length).trim().split(/\s+/).filter(Boolean);
  const command = (args.shift() || 'help').toLowerCase();

  try {
    if (['help', '帮助', '菜单'].includes(command)) {
      await sendReply(event, buildCommandHelp(prefix), ctx);
      return;
    }
    if (['发电'].includes(command)) {
      await sendReply(event, buildAfdianHomeMessage(), ctx);
      return;
    }
    if (['赞助列表', 'sponsors', 'sponsor'].includes(command)) {
      await sendReply(event, await buildSponsorListMessage(), ctx);
      return;
    }

    if (!isCommandAdmin(event)) {
      await sendReply(event, `你没有权限使用该管理指令。可发送 ${prefix} help 查看所有指令。`, ctx);
      return;
    }

    if (['test', '测试'].includes(command)) {
      const result = await notifyAfdianEvent(ctx, normalizeAfdianEvent(buildTestEvent()), { isTest: true, skipDedupe: true });
      await sendReply(event, `测试通知已发送：${result.targets.filter((item) => item.status === 'success').length}/${result.targets.length} 成功`, ctx);
      return;
    }
    if (['status', '状态'].includes(command)) {
      await sendReply(event, `AfdianNap：${currentConfig.enabled ? '已启用' : '已停用'}\n通知目标：群 ${currentConfig.notifyGroups.length} / 私聊 ${currentConfig.notifyUsers.length}\n历史记录：${notificationHistory.length}\n运行时间：${formatUptime(Date.now() - startTime)}`, ctx);
      return;
    }
    if (['history', '历史'].includes(command)) {
      const limit = Math.min(10, Math.max(1, Number(args[0]) || 5));
      await sendReply(event, formatHistoryForMessage(limit), ctx);
      return;
    }
    if (['order', '订单'].includes(command)) {
      const outTradeNo = args[0];
      if (!outTradeNo) {
        await sendReply(event, `格式：${prefix} order <订单号>\n备注：订单号一般是 2026 开头的爱发电订单号。`, ctx);
        return;
      }
      const order = await queryAfdianOrder(outTradeNo);
      await sendReply(event, formatOrderForMessage(order), ctx);
      return;
    }
    if (['orders', '订单列表'].includes(command)) {
      const page = Math.max(1, Number(args[0]) || 1);
      const perPage = Math.min(10, Math.max(1, Number(args[1]) || 5));
      const result = await queryAfdianOrders({ page, per_page: perPage });
      await sendReply(event, formatOrdersForMessage(result), ctx);
      return;
    }
    await sendReply(event, buildCommandHelp(prefix), ctx);
  } catch (error) {
    logger?.error('处理爱发电 QQ 指令失败:', error);
    await sendReply(event, `爱发电指令执行失败：${error.message}`, ctx);
  }
}

function buildAfdianHomeMessage() {
  if (!currentConfig.afdianHomeUrl) {
    return '管理员还没有配置爱发电主页地址。';
  }
  return `💜 支持我们发电\n${currentConfig.afdianHomeUrl}`;
}

async function buildSponsorListMessage() {
  const perPage = 100;
  const maxPages = currentConfig.sponsorListPages || defaultConfig.sponsorListPages;
  const sponsorMap = new Map();
  let failedPages = 0;

  for (let page = 1; page <= maxPages; page++) {
    let result;
    try {
      result = await queryAfdianOrders({ page, per_page: perPage });
    } catch (error) {
      logger?.warn(`查询赞助列表第 ${page} 页失败:`, error.message);
      failedPages++;
      continue;
    }
    const orders = extractAfdianOrderList(result);
    if (!orders.length) break;

    for (const order of orders) {
      const event = normalizeAfdianEvent(order);
      const key = event.userId || event.userName || event.outTradeNo || event.orderId;
      if (!key || key === 'unknown') continue;
      const old = sponsorMap.get(key) || {
        userName: event.userName || '未知用户',
        userId: event.userId || '',
        amount: 0,
        count: 0,
        lastTime: ''
      };
      old.userName = event.userName || old.userName;
      old.userId = event.userId || old.userId;
      const parsedAmount = parseAmount(event.amount);
      old.amount += Number.isFinite(parsedAmount) ? parsedAmount : 0;
      old.count += 1;
      old.lastTime = event.time || old.lastTime;
      sponsorMap.set(key, old);
    }
  }

  if (!sponsorMap.size) {
    return failedPages > 0
      ? `查询赞助列表失败（${failedPages} 页请求出错），请检查爱发电 API 配置。`
      : '暂未查询到赞助者。';
  }

  const sponsors = [...sponsorMap.values()].sort((a, b) => b.amount - a.amount || b.count - a.count);
  const warning = failedPages > 0 ? `（注意：有 ${failedPages} 页查询失败，数据可能不完整）\n` : '';

  return `💜 赞助列表（共 ${sponsors.length} 位）\n` + warning + sponsors.slice(0, 30).map((item, index) => {
    const amountText = item.amount > 0 ? `累计 ${formatAmount(item.amount)} 元` : `订单 ${item.count} 次`;
    return `${index + 1}. ${item.userName} - ${amountText}`;
  }).join('\n') + (sponsors.length > 30 ? `\n...还有 ${sponsors.length - 30} 位赞助者` : '');
}

function parseAmount(value) {
  if (value === undefined || value === null || value === '') return NaN;
  const num = parseFloat(value);
  return Number.isFinite(num) ? num : NaN;
}

function formatAmount(value) {
  return Number(value || 0).toFixed(2).replace(/\.00$/, '');
}

function isCommandAdmin(event) {
  const userId = String(event?.user_id || '');
  return Boolean(userId && currentConfig.commandAdmins.includes(userId));
}

async function sendReply(event, message, ctx) {
  if (!message || !ctx?.actions) return;
  const replyMessage = event.message_id
    ? [{ type: 'reply', data: { id: String(event.message_id) } }, { type: 'text', data: { text: String(message) } }]
    : message;
  const target = event.message_type === 'group'
    ? { group_id: String(event.group_id) }
    : { user_id: String(event.user_id || event.sender?.user_id || '') };
  if (!target.group_id && !target.user_id) {
    logger?.warn('发送指令回复失败：无法确定消息目标', { message_type: event.message_type });
    return;
  }
  await ctx.actions.call('send_msg', {
    message_type: event.message_type === 'group' ? 'group' : 'private',
    message: replyMessage,
    ...target
  }, ctx.adapterName, ctx.pluginManager.config).catch((error) => {
    logger?.warn('发送指令回复失败:', error);
  });
}

function buildCommandHelp(prefix) {
  return `💜 爱发电指令\n${DEVELOPER_TEXT}\n\n【所有用户可用】\n${prefix} 发电 - 查看爱发电主页\n${prefix} 赞助列表 - 查看所有赞助者\n${prefix} help - 查看本菜单\n\n【管理员可用】\n${prefix} status - 查看插件状态\n${prefix} test - 发送测试通知\n${prefix} history [数量] - 查看最近通知\n${prefix} order <订单号> - 查询订单详情（订单号一般是 2026 开头）\n${prefix} orders [页码] [数量] - 查询订单列表`;
}

function formatHistoryForMessage(limit) {
  const items = notificationHistory.slice(0, limit);
  if (!items.length) return '暂无爱发电通知历史';
  return items.map((item, index) => {
    const event = item.event || {};
    return `${index + 1}. [${item.status}] ${event.userName || '未知用户'} / ${event.planTitle || '未知方案'} / ${event.amount || '未知'} 元\n订单：${event.outTradeNo || event.orderId || '未知'}\n时间：${item.createdAt || event.time || '未知'}`;
  }).join('\n\n');
}

function formatOrderForMessage(order) {
  const event = normalizeAfdianEvent(order || {});
  return `爱发电订单详情\n订单：${event.outTradeNo || event.orderId}\n用户：${event.userName}\n方案：${event.planTitle}\n金额：${event.amount} 元\n月份：${event.month || '未知'}\n留言：${event.remark || '无'}\n时间：${event.time}`;
}

function formatOrdersForMessage(result) {
  const list = extractAfdianOrderList(result).slice(0, 10);
  if (!list.length) return '未查询到爱发电订单';
  return `爱发电订单列表\n` + list.map((order, index) => {
    const event = normalizeAfdianEvent(order);
    return `${index + 1}. ${event.userName} / ${event.planTitle} / ${event.amount} 元\n订单：${event.outTradeNo || event.orderId}`;
  }).join('\n\n');
}

export {
  plugin_config_controller,
  plugin_config_ui,
  plugin_get_config,
  plugin_init,
  plugin_on_config_change,
  plugin_onevent,
  plugin_onmessage,
  plugin_set_config
};
